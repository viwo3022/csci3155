package edu.colorado.csci3155.project1

object StackMachineCompiler {



    /* Function compileToStackMachineCode
        Given expression e as input, return a corresponding list of stack machine instructions.
        The type of stack machine instructions are in the file StackMachineEmulator.scala in this same directory
        The type of Expr is in the file Expr.scala in this directory.
     */
    def compileToStackMachineCode(e: Expr): List[StackMachineInstruction] = {
        var insList= List[StackMachineInstruction]()
        e match {

            case Const(f) => PushI(f) :: insList
            case Plus(e1, e2) => {
                compileToStackMachineCode(e1) ++ compileToStackMachineCode(e2) ++ (AddI :: insList)
            }
            case Minus(e1, e2) => {

                compileToStackMachineCode(e1) ++ compileToStackMachineCode(e2) ++ (SubI :: insList)
            }

            case Ident(id) => {
                StoreI(id) :: insList
            }
            case Mult(e1, e2) => {

                compileToStackMachineCode(e1) ++ (compileToStackMachineCode(e2) ++  (MultI :: insList))
            }
            case Div(e1, e2) => {

                compileToStackMachineCode(e1) ++ (compileToStackMachineCode(e2) ++ (DivI :: insList))
            }
            case Exp(e1) => {

                compileToStackMachineCode(e1) ++ (ExpI :: insList)
            }
            case Log(e1) => {

                compileToStackMachineCode(e1) ++ (LogI :: insList)
            }
            case Sine(e1) => {

                compileToStackMachineCode(e1) ++ ( SinI :: insList)
            }
            case Cosine(e1) => {

                compileToStackMachineCode(e1) ++ (CosI :: insList)
            }
            case Let(ident, e1, e2)=> {

                compileToStackMachineCode(e1) ++ (LoadI(ident) :: insList) ++ (compileToStackMachineCode(e2))
            }
        }
    }

}
