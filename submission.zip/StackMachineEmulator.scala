package edu.colorado.csci3155.project1

import java.sql.DataTruncation

import scala.collection.JavaConverters._
//import scala.collection.Map


/* -- Here are all the instructions to be supported --*/
sealed trait StackMachineInstruction
case class LoadI(s: String) extends StackMachineInstruction
case class  StoreI(s: String) extends StackMachineInstruction
case class PushI(f: Double) extends StackMachineInstruction
case object AddI extends StackMachineInstruction
case object SubI extends StackMachineInstruction
case object MultI extends StackMachineInstruction
case object DivI extends StackMachineInstruction
case object ExpI extends StackMachineInstruction
case object LogI extends StackMachineInstruction
case object SinI extends StackMachineInstruction
case object CosI extends StackMachineInstruction
case object PopI extends StackMachineInstruction


object StackMachineEmulator {



    /* Function emulateSingleInstruction
        Given a list of doubles to represent a stack
              a map from string to double precision numbers for the environment
        and   a single instruction of type StackMachineInstruction
        Return a tuple that contains the
              modified stack that results when the instruction is executed.
              modified environment that results when the instruction is executed.

        Make sure you handle the error cases: eg., stack size must be appropriate for the instruction
        being executed. Division by zero, log of a non negative number
        Throw an exception or assertion violation when error happens.
     */
    def emulateSingleInstruction(stack: List[Double],
                                 env: Map[String, Double],
                                 ins: StackMachineInstruction): (List[Double], Map[String, Double]) = {
        ins match {
            case LoadI(s) => {
                if (stack.isEmpty) {
                    throw new IllegalArgumentException("Stack is Empty ")
                }
                if (s == "") {
                    throw new IllegalArgumentException("Identifier is not present")
                }
                val v = stack.head
                val update = env + (s -> v)
                emulateSingleInstruction(stack, update, PopI)
            }

            case StoreI(s) => {
                if (s == "") {
                    throw new IllegalArgumentException("Identifier is not present")
                }
                val a = env(s)
                emulateSingleInstruction(stack, env, PushI(a))
            }

            case PushI(f) => (f :: stack, env)


            case AddI => {
                if (stack.isEmpty) {
                    throw new IllegalArgumentException("Stack is Empty ")
                }
                print(stack)
                val v1 = stack.head
                print(v1)
                val popV1 = emulateSingleInstruction(stack, env, PopI)
                print(popV1)
                if (popV1._1.isEmpty) {
                    throw new IllegalArgumentException("Stack is too small")
                }

                val v2 = popV1._1.head
                print(v2)
                val popV2 = emulateSingleInstruction(popV1._1, env, PopI)
                print(popV2)


                val added = v1 + v2

                return emulateSingleInstruction(popV2._1, env, PushI(added))

            }

            case SubI => {
                //stack is empty
                if (stack.isEmpty) {
                    throw new IllegalArgumentException("Stack is Empty")
                }
                //takes first elem of stack
                val v1 = stack.head

                //pop first elem
                val popV1 = emulateSingleInstruction(stack, env, PopI)

                //stack is empty after first pop
                if (popV1._1.isEmpty) {
                    throw new IllegalArgumentException("Stack is too small")
                }

                //takes seconds elem of stack
                val v2 = popV1._1.head

                //pop second elem
                val popV2 = emulateSingleInstruction(popV1._1, env, PopI)


                val sub = v2 - v1
                emulateSingleInstruction(popV2._1, env, PushI(sub))

            }

            case MultI => {
                //stack is empty
                if (stack.isEmpty) {
                    throw new IllegalArgumentException("Stack is Empty")
                }
                //takes first elem of stack
                val v1 = stack.head

                //pop first elem
                val popV1 = emulateSingleInstruction(stack, env, PopI)

                //stack is empty after first pop
                if (popV1._1.isEmpty) {
                    throw new IllegalArgumentException("Stack is too small")
                }

                //takes seconds elem of stack
                val v2 = popV1._1.head

                //pop second elem
                val popV2 = emulateSingleInstruction(popV1._1, env, PopI)


                val mult = v1 * v2
                emulateSingleInstruction(popV2._1, env, PushI(mult))
            }
            //
            case DivI => {
                //stack is empty
                if (stack.isEmpty) {
                    throw new IllegalArgumentException("Stack is Empty")
                }
                //takes first elem of stack
                val v1 = stack.head

                //pop first elem
                val popV1 = emulateSingleInstruction(stack, env, PopI)

                if (v1 == 0) {
                    throw new IllegalArgumentException("Cannot divide by zero")
                }

                //stack is empty after first pop
                if (popV1._1.isEmpty) {
                    throw new IllegalArgumentException("Stack is too small")
                }

                //takes seconds elem of stack
                val v2 = popV1._1.head

                //pop second elem
                val popV2 = emulateSingleInstruction(popV1._1, env, PopI)


                val div = v2 / v1
                emulateSingleInstruction(popV2._1, env, PushI(div))
            }


            case LogI => {
                if (stack.isEmpty) {
                    throw new IllegalArgumentException("Stack is Empty")
                }
                //takes first elem of stack
                val v1 = stack.head
                val popped = emulateSingleInstruction(stack, env, PopI)
                if (v1 < 0) {
                    throw new IllegalArgumentException("Can not take log of a negative number")
                }

                val log = scala.math.log(v1)
                emulateSingleInstruction(popped._1, env, PushI(log))

            }

            case ExpI => {
                if (stack.isEmpty) {
                    throw new IllegalArgumentException("Stack is Empty")
                }
                val v1 = stack.head
                val popped = emulateSingleInstruction(stack, env, PopI)
                val ex = scala.math.exp(v1)
                emulateSingleInstruction(popped._1, env, PushI(ex))
            }


            case SinI => {
                if (stack.isEmpty) {
                    throw new IllegalArgumentException("Stack is Empty")
                }
                val v1 = stack.head
                val popped = emulateSingleInstruction(stack, env, PopI)
                val c = scala.math.sin(v1)
                emulateSingleInstruction(popped._1, env, PushI(c))
            }
            case CosI => {
                if (stack.isEmpty) {
                    throw new IllegalArgumentException("Stack is Empty")
                }
                val v1 = stack.head
                val popped = emulateSingleInstruction(stack, env, PopI)
                val c = scala.math.cos(v1)
                emulateSingleInstruction(popped._1, env, PushI(c))
            }

            case PopI => {
                val newlist = stack.tail
                (newlist, env)
            }


        }

    }


    /* Function emulateStackMachine
       Execute the list of instructions provided as inputs using the
       emulateSingleInstruction function.
       Use foldLeft over list of instruction rather than a for loop if you can.
       Return value must be the final environment.

       Hint: accumulator for foldLeft must be a tuple (List[Double], Map[String,Double])
             initial value of this accumulator must be (Nil, Map.empty)
             You should use emulateSingleInstruction to update the accmulator.
             It will all fit nicely once you figure it out.
     */


    def emulateStackMachine(instructionList: List[StackMachineInstruction]): Map[String, Double] =
    {
        val (myStack, myEnv) = {
            instructionList.foldLeft[(List[Double], Map[String, Double])]((Nil, Map.empty[String,Double]))((acc, ins) => emulateSingleInstruction(acc._1, acc._2, ins))
        }
        return myEnv



    }



}